// Importa la aplicación Express configurada en app.ts.
import 'dotenv/config'

// Allí están los middlewares, las rutas y la configuración del frontend.
import app from './app'

// Importa el puerto definido en las variables de entorno (.env).
import { PORT } from './config/env'

// Importa la función que realiza la conexión con PostgreSQL.
import { conexion_db } from './config/db'
import { iniciarSchedulerRecordatorios } from './infrastructure/scheduler/recordatorios.scheduler'

app.listen(PORT, async () => {

  await conexion_db();

  iniciarSchedulerRecordatorios();

  console.log(`\x1b[32m🟢 Servidor corriendo en puerto ${PORT}\x1b[0m`)
})

// Captura la combinación Ctrl + C en la terminal.
// Permite finalizar el servidor de forma controlada.
process.on('SIGINT', () => {

  console.log('\n🛑 Servidor detenido')

  process.exit(0)
})

// Captura cuando el sistema operativo o un administrador
// solicita terminar el proceso del servidor.
process.on('SIGTERM', () => {

  console.log('🛑 Servidor terminado (SIGTERM)')

  process.exit(0)
})


